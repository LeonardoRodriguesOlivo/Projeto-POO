
import java.util.Scanner;

class Usuario {
    protected String nome;
    protected String cpf;

    public Usuario(String nome, String cpf) {
        this.nome = nome;
        this.cpf = cpf;
    }

    public void mostrarDados() {
        System.out.println("Nome: " + nome);
        System.out.println("CPF: " + cpf);
    }
}

class Cliente extends Usuario {
    private String email;
    private String endereco;

    public Cliente(String nome, String cpf, String email, String endereco) {
        super(nome, cpf);
        this.email = email;
        this.endereco = endereco;
    }


    public void mostrarDados() {
        System.out.println("----CLIENTE----");
        super.mostrarDados();
        System.out.println("Email: " + email);
        System.out.println("Endereço: " + endereco);
    }
}

class Funcionario extends Usuario {
    private String email;
    private int codigo;

    public Funcionario(String nome, String cpf, String email, int codigo) {
        super(nome, cpf);
        this.email = email;
        this.codigo = codigo;
    }

    public void mostrarDados() {
        System.out.println("----FUNCIONÁRIO----");
        super.mostrarDados();
        System.out.println("Email: " + email);
        System.out.println("Código: " + codigo);
    }
}

class Item {
    protected String titulo;
    protected String autor;
    protected double preco;

    public Item(String titulo, String autor, double preco) {
        this.titulo = titulo;
        this.autor = autor;
        this.preco = preco;
    }

    public void mostrarDados() {
        System.out.println("Titulo: " + titulo);
        System.out.println("Autor: " + autor);
        System.out.println("Preço: R$ " + preco);
    }
}

class Livro extends Item {
    private int numeroPaginas;
    private String categoria;

    public Livro(String titulo, String autor, double preco,
        int numeroPaginas, String categoria) {
        super(titulo, autor, preco);
        this.numeroPaginas = numeroPaginas;
        this.categoria = categoria;
    }

    public void mostrarDados() {
        System.out.println("----LIVRO----");
        super.mostrarDados();
        System.out.println("Paginas: " + numeroPaginas);
        System.out.println("Categoria: " + categoria);
    }
}

public class biblioteca {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Usuario[] usuarios = new Usuario[100];
        Livro[] livros = new Livro[100];

        int qtdUsuarios = 0;
        int qtdLivros = 0;

        int opcao;

        do {
            System.out.println("======BIBLIOTECA======");
            System.out.println("----------------------");
            System.out.println("1 - Cadastro de Cliente");
            System.out.println("----------------------");
            System.out.println("2 - Área do Funcionário");
            System.out.println("----------------------");
            System.out.println("3 - Catálogo");
            System.out.println("----------------------");
            System.out.println("0 - Sair");

            opcao = sc.nextInt();
            sc.nextLine();

            switch (opcao) {

                case 1:

                    System.out.print("Nome: ");
                    String nome = sc.nextLine();

                    System.out.print("CPF: ");
                    String cpf = sc.nextLine();

                    System.out.print("Email: ");
                    String email = sc.nextLine();

                    System.out.print("Endereço: ");
                    String endereco = sc.nextLine();

                    usuarios[qtdUsuarios++] =
                            new Cliente(nome, cpf, email, endereco);

                    System.out.println("Cadastro concluido com sucesso");
                    break;

                case 2:
                    System.out.println("AVISO PARA A PROFESSORA: para entrar na area de funcionarios eu coloquei uma senha. A senha é 1234. ");
                    System.out.print("Digite a senha de acesso: ");
                    String senha = sc.nextLine();

                    if (!senha.equals("1234")) {
                        System.out.println("Senha incorreta");
                        break;
                    }

                    int opFunc;

                    do {

                        System.out.println("======FUNCIONÁRIOS======");
                        System.out.println("----------------------");
                        System.out.println("1 - Cadastro de funcionario");
                        System.out.println("----------------------");
                        System.out.println("2 - Cadastrar livros");
                        System.out.println("----------------------");
                        System.out.println("3 - Mostrar clientes");
                        System.out.println("----------------------");
                        System.out.println("0 - Voltar");

                        opFunc = sc.nextInt();
                        sc.nextLine();

                        switch (opFunc) {

                            case 1:

                                System.out.print("Nome: ");
                                String nomeF = sc.nextLine();

                                System.out.print("CPF: ");
                                String cpfF = sc.nextLine();

                                System.out.print("Email: ");
                                String emailF = sc.nextLine();

                                System.out.print("Código: ");
                                int codigo = sc.nextInt();
                                sc.nextLine();

                                usuarios[qtdUsuarios++] =
                                        new Funcionario(nomeF, cpfF, emailF, codigo);

                                System.out.println("Cadastro de funcionario efetuado com sucesso");
                                break;

                            case 2:

                                System.out.print("Titulo: ");
                                String titulo = sc.nextLine();

                                System.out.print("Autor: ");
                                String autor = sc.nextLine();

                                System.out.print("Preço: ");
                                double preco = sc.nextDouble();

                                System.out.print("Número de páginas: ");
                                int paginas = sc.nextInt();
                                sc.nextLine();

                                System.out.print("Categoria: ");
                                String categoria = sc.nextLine();

                                livros[qtdLivros++] =
                                        new Livro(titulo, autor, preco, paginas, categoria);

                                System.out.println("Livro cadastrado!");
                                break;

                            case 3:

                                System.out.println("======CLIENTES CADASTRADOS======");

                                for (int i = 0; i < qtdUsuarios; i++) {
                                    if (usuarios[i] instanceof Cliente) {
                                        usuarios[i].mostrarDados();
                                    }
                                }

                                break;
                        }

                    } while (opFunc != 0);

                    break;

                case 3:

                    System.out.println("======LIVROS======");

                    for (int i = 0; i < qtdLivros; i++) {
                        livros[i].mostrarDados();
                    }

                    break;

                case 0:
                    System.out.println("Sistema encerrado");
                    break;

                default:
                    System.out.println("Opção invalida");
            }

        } while (opcao != 0);

        sc.close();
    }
}